import React from 'react';
import { useState, useEffect } from 'react'

import ProjectService from '../services/ProjectService';
import AddNewProject from './AddNewProject';
import ProjectCard from './ProjectCard';
import Container from '@material-ui/core/Container';
import Grid from '@material-ui/core/Grid';

import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  root: {
    marginTop: 36,
    flexGrow: 1
  },
  paper: {
    height: 140,
    width: 100,
  },
  control: {
    padding: theme.spacing(2),
  },
}));

/**
 * Displays all users projects grouped in two categories: 
 * - users own projects 
 * - project the user is working on
 * 
 * Contains: 'AddNewProject' and 'ProjectCard'
 */
const Projects = () => {
  const classes = useStyles();
  const [spacing, setSpacing] = React.useState(5);
  const [projects, setProjects] = useState();

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = () => {
    ProjectService.get({ pageNumber: 1, pageSize: 53 })
      .then(projects => {
        setProjects(projects);
      });
  };

  return (
    <Container>
      <Grid container className={classes.root} spacing={5}>
        <Grid item xs={12}>
          <Grid container spacing={spacing}>
            <AddNewProject saveSuccessful={() => loadProjects()} />
            {projects && projects.map(project => (
              <ProjectCard project={project} />
            ))}
          </Grid>
        </Grid>
      </Grid>
    </Container>
  );
}

export default Projects;