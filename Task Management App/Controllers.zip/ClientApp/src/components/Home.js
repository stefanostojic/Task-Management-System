import React from 'react';

//STATELESS FUNCTIONAL COMPONENT
const Home = (props) => {
    return (
        <div>
            Home
        </div>
    );
}

export default Home;