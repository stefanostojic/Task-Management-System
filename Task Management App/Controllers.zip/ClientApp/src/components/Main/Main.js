import React from 'react';

const Main = () => {
	return (
		<>
			Main
		</>
	);
};

export default Main;