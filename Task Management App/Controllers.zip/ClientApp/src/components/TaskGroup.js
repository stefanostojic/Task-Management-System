import React from 'react';
import { useState, useEffect } from 'react'
import {
  // BrowserRouter as Router,
  // Switch,
  // Route,
  // Link,
  // useRouteMatch,
  useParams
} from "react-router-dom";
import TaskService from '../services/TaskService';
import TaskCard from './TaskCard';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  root: {
    width: 300,
    minWidth: 300,
    // padding: 12,
    margin: 10,
    boxShadow: '2px 3px 7px 2px lightgrey',
    position: 'relative'
  },
  subRoot1: {

  },
  subRoot2: {
    padding: 12
  },
  label: {
    fontSize: 12,
    color: '#b0b0b0',
    margin: 0
  },
  title: {
    fontSize: 32,
    margin: 0
  },
  description: {
    fontSize: 14,
    color: 'darkgray',
    margin: 0
  },
  addNewTaskButton: {
    padding: 6,
    boxShadow: '2px 3px 7px 2px lightgrey',
    marginTop: 12,
    borderRadius: 4,
    textAlign: 'center',
    color: 'white',
    backgroundColor: '#007bff',
    cursor: 'pointer'
  },
  edit: {
    position: 'absolute',
    top: -9,
    right: -8,
    width: 16,
    height: 16,
    background: 'blue',
    fontSize: 10,
    color: 'white'
  }
});

const TaskGroup = ({ taskGroup }) => {
  const classes = useStyles();
  let { id } = useParams();
  const [tasks, setTasks] = useState([]);
  const [mouseOver, setMouseOver] = useState(false);

  useEffect(() => {
    TaskService.get({ taskGroupId: taskGroup.id, pageNumber: 1, pageSize: 2 })
      .then(tasks => {
        setTasks(tasks);
      });
  }, []);

  return (
    <div className={classes.root}>

      <div className={classes.subRoot2} onMouseEnter={() => setMouseOver(true)} onMouseLeave={() => setMouseOver(false)}>
        <p className={classes.title}>{taskGroup.name}</p>
        <p className={classes.description}>{taskGroup.description}</p>

        {mouseOver && <div className={classes.edit}>S</div>}
      </div>

      <div className={classes.subRoot2}>
        {tasks && tasks.map(task => (
          <TaskCard key={task.id} task={task} />
        ))}
        {tasks && tasks.length === 0 && (
          <p className={classes.description} style={{ marginTop: '15px' }}>No tasks yet.</p>
        )}
        <div className={classes.addNewTaskButton}>
          Add new task
        </div>
      </div>


      
    </div>
  );
}

export default TaskGroup;