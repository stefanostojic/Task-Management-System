import React from 'react';
import { useState } from 'react'
// import { useEffect } from 'react'
// import {
//   BrowserRouter as Router,
//   Switch,
//   Route,
//   Link,
//   useRouteMatch,
//   useParams
// } from "react-router-dom";
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  root: {
    minWidth: 275,
    padding: 16,
    margin: 10,
    // boxShadow: '2px 3px 7px 2px lightgrey',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  plusContainer: {
    width: '150px',
    height: '150px',
    fontSize: 100,
    backgroundColor: '#688df6',
    borderRadius: '100px',
    color: 'white',
    cursor: 'pointer'
  },
  plus: {

  },
  modal: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
    width: '100px'
  }
});

/**
 * A button for adding new projects. Opens a modal dialog form on click.
 */
const AddNewTaskGroup = (props) => {
  const classes = useStyles();
  const [modalIsOpen, setIsOpen] = useState(false);
  // const [projects, setProjects] = useState();

  // useEffect(() => {
  //   ProjectService.Get(1)
  //     .then(projects => {
  //       setProjects(projects);
  //     });
  // }, []);

  return (
    <div className='container'>
      <div class="form-group mt-5">
        <label for="exampleInputEmail1">Task group name</label>
        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter task group name" />
        <small id="emailHelp" class="form-text text-muted">The task group name must be between 1 and 15 letters long.</small>
      </div>
    </div>
  );
}

export default AddNewTaskGroup;