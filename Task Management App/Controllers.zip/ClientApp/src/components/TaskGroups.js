// import { Button } from 'bootstrap';
import React from 'react';
import { useState, useEffect } from 'react'
import {
  // BrowserRouter as Router,
  // Switch,
  // Route,
  Link,
  // useRouteMatch,
  useParams
} from "react-router-dom";
import TaskGroupService from '../services/TaskGroupService';
import TaskGroup from './TaskGroup';
// import AddNewTaskGroup from './AddNewTaskGroup';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  root: {
    minWidth: 275,
    maxWidth: 275,
    padding: 16,
    margin: 10,
    oveflowX: 'scroll',
    // boxShadow: '2px 3px 7px 2px lightgrey',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  plusContainer: {
    width: '150px',
    height: '150px',
    fontSize: 100,
    backgroundColor: '#688df6',
    borderRadius: '100px',
    color: 'white',
    cursor: 'pointer'
  },
  plus: {

  }
});

/**
 * Displays all task groups for a given projectId.
 * 
 * Contains: 'TaskGroup'
 * 
 * @param {string} projectId  
 */
const TaskGroups = ({ projectId }) => {
  let { id } = useParams();
  const [taskGroups, setTaskGroups] = useState([]);
  const [showAddNewTaskGroup, setShowAddNewTaskGroup] = useState(false);
  const [newTaskGroupName, setNewTaskGroupName] = useState('');
  const [newTaskGroupDescription, setNewTaskGroupDescription] = useState('');
  // const [resetName, setResetName] = useState('');
  const classes = useStyles();

  useEffect(() => {
    TaskGroupService.getByProjectId(projectId)
      .then(taskGroups => {
        setTaskGroups(taskGroups);
      });
  }, []);

  const saveNewTaskGroup = () => {
    TaskGroupService.post({
      name: newTaskGroupName, 
      description: newTaskGroupDescription,
      projectID: projectId
    }).then(newTaskGroup => {
      console.info('New task group added', newTaskGroup);

      TaskGroupService.getByProjectId(projectId)
      .then(taskGroups => {
        setTaskGroups(taskGroups);
      });
    });
    cancelNewTaskGroup();
  };
  const cancelNewTaskGroup = () => {
    setShowAddNewTaskGroup(false);
    setNewTaskGroupName('');
    setNewTaskGroupDescription('');
    // setResetName('');
  };

  return (
    <div>
      {/* <p>Task groups:</p> */}
      <button className='btn btn-primary'>Add new task group</button>
      <div className="d-flex flex-row">
        {taskGroups && taskGroups.map(taskGroup => (
          <TaskGroup key={taskGroup.id} taskGroup={taskGroup} />
        ))}
        <div className={classes.root}>
          <Link className={classes.plusContainer} style={{display: (showAddNewTaskGroup) ? 'none' : 'block'}} onClick={() => setShowAddNewTaskGroup(!showAddNewTaskGroup)}>
            <div className='text-center' style={{ lineHeight: '1.3em' }}>
              +
            </div>
          </Link>
          <div style={{display: (showAddNewTaskGroup) ? 'block' : 'none'}}>
            <div className="form-group mt-5">
              <label>New task group</label>
              <input type="text" className="form-control" placeholder="Name" value={newTaskGroupName} onChange={(e) => setNewTaskGroupName(e.target.value)} />
              <small className="form-text text-muted mb-3">The task group name must be between 1 and 15 letters long.</small>
              <input type="text" className="form-control" placeholder="Description" value={newTaskGroupDescription} onChange={(e) => setNewTaskGroupDescription(e.target.value)} />
              <small  className="form-text text-muted mb-3">The task group description must be between 1 and 255 letters long.</small>
              <button className='btn btn-danger float-left' onClick={() => cancelNewTaskGroup()}>Cancel</button>
              <button className='btn btn-primary float-right' onClick={() => saveNewTaskGroup()}>Add</button>
            </div>
          </div>
        </div>
      </div>
      {taskGroups && taskGroups.length === 0 && (
        <p>No task groups yet.</p>
      )}
    </div>
  );
}

export default TaskGroups;