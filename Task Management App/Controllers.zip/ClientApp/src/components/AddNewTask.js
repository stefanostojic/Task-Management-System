import React from 'react';
import { useState, useEffect } from 'react'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useRouteMatch,
  useParams
} from "react-router-dom";
import TaskService from '../services/TaskService';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  root: {
    minWidth: 275,
    maxWidth: 275,
    padding: 16,
    margin: 10,
    oveflowX: 'scroll',
    // boxShadow: '2px 3px 7px 2px lightgrey',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  plusContainer: {
    width: '150px',
    height: '150px',
    fontSize: 100,
    backgroundColor: '#688df6',
    borderRadius: '100px',
    color: 'white',
    cursor: 'pointer'
  },
  plus: {

  }
});

/**
 * A screen for creating and editing tasks.
 */
const AddNewTask = (props) => {
  let { projectId, taskGroupId } = useParams();
  const [newName, setNewName] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newFinished, setNewFinished] = useState(false);
  const [newDueDate, setNewDueDate] = useState(null);
  const classes = useStyles();

  const saveNewTask = () => {
    TaskService.post({
      name: newName,
      description: newDescription,
      finished: newFinished,
      dueDate: newDueDate,
      taskGroupID: taskGroupId
    }).then(newTask => {
      console.info('New task added', newTask);

      props.history.goBack()
    });
  };
  const cancelNewTask = () => {
    props.history.goBack()
  };

  return (
    <div className="form-group mt-5">
      <label>New task</label>
      <input type="text" className="form-control" placeholder="Name" value={newName} onChange={(e) => setNewName(e.target.value)} />
      <small className="form-text text-muted mb-3">The task group name must be between 1 and 15 letters long.</small>
      <input type="text" className="form-control" placeholder="Description" value={newDescription} onChange={(e) => setNewDescription(e.target.value)} />
      <small className="form-text text-muted mb-3">The task group description must be between 1 and 255 letters long.</small>
      <Link to={`projects/${projectId}`}>
        <button className='btn btn-danger float-left' onClick={() => cancelNewTask()}>Cancel</button>
      </Link>
      <button className='btn btn-primary float-right' onClick={() => saveNewTask()}>Add</button>
    </div>
  );
}

export default AddNewTask;