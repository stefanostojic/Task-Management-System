﻿using Task_Management_System.Models;

namespace Task_Management_System.Repositories.SubtaskRepository
{
    public interface ISubtaskRepository : IGenericRepository<Subtask>
    {
    }
}
