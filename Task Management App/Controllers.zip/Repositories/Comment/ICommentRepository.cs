﻿using Task_Management_System.Models;

namespace Task_Management_System.Repositories.CommentRepository
{
    public interface ICommentRepository : IGenericRepository<Comment>
    {
    }
}
