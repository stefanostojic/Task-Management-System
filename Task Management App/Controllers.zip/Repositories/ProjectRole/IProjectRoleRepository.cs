﻿using Task_Management_System.Models;

namespace Task_Management_System.Repositories.ProjectRoleRepository
{
    public interface IProjectRoleRepository : IGenericRepository<ProjectRole>
    {
    }
}
