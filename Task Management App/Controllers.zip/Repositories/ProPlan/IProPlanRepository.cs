﻿using Task_Management_System.Models;

namespace Task_Management_System.Repositories.ProjectRepository
{
    public interface IProPlanRepository : IGenericRepository<ProPlan>
    {
    }
}
