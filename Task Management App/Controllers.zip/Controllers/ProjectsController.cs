﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Task_Management_System.DTO;
using Task_Management_System.Models.Dtos;
using Task_Management_System.Services.ProjectService;

namespace Task_Management_System.Controllers
{
    [ApiController]
    [Route("api/projects")]
    [Produces("application/json")]
    public class ProjectsController : ControllerBase
    {
        private readonly IProjectService projectService;
        private readonly IMapper mapper;
        private readonly ILogger<ProjectsController> _logger;

        public ProjectsController(IProjectService projectService, IMapper mapper, ILogger<ProjectsController> _logger)
        {
            this.projectService = projectService;
            this.mapper = mapper;
            this._logger = _logger;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProjectResponseDto>>> GetProjects([FromQuery] PaginationFilter paginationFilter)
        {
            var projects = await projectService.GetAllAsync(paginationFilter);


            //_logger.LogInformation(JsonConvert.SerializeObject(projects));

            return Ok(mapper.Map<List<ProjectResponseDto>>(projects));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetProjectById(Guid id)
        {
            var project = await projectService.GetByIdAsync(id);

            if (project == null)
            {
                return NotFound();
            }

            return Ok(mapper.Map<ProjectResponseDto>(project));
        }

        [HttpPost]
        public async Task<IActionResult> AddNewProject([FromBody] ProjectPostDto projectPostDto)
        {
            var projectResp = await projectService.AddAsync(projectPostDto);

            return CreatedAtAction("AddNewProject", new { id = projectResp.ID }, mapper.Map<ProjectResponseDto>(projectResp));
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Edit([FromQuery] Guid id, [FromBody] ProjectPutDto projectPutDto)
        {
            if (id != projectPutDto.ID)
            {
                return BadRequest();
            }

            await projectService.UpdateAsync(projectPutDto);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProject(Guid id)
        {
            var success = await projectService.RemoveByIdAsync(id);

            if (!success)
            {
                return NotFound();
            }

            return NoContent();
        }
    }
}
