﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Task_Management_System.Auth;
using Task_Management_System.DTO;
using Task_Management_System.Models;
using Task_Management_System.Models.Dtos;
using Task_Management_System.Services.UserService;

namespace Task_Management_System.Controllers
{
    [Route("api/users")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserService userService;
        private readonly IMapper mapper;
        private UserManager<User> UserManager { get; }
        private SignInManager<User> SignInManager { get; }

        public UsersController(IUserService service, UserManager<User> userManager, SignInManager<User> signInManager, IMapper mapper)
        {
            this.userService = service;
            this.mapper = mapper;
            UserManager = userManager;
            SignInManager = signInManager;
        }

        [HttpPost]
        [Route("[action]")]
        public async Task<IActionResult> CreateToken([FromQuery] string username, [FromQuery] string password)
        {
            User user = await UserManager.FindByNameAsync(username);
            var signInResult = await SignInManager.CheckPasswordSignInAsync(user, password, false);
            if (signInResult.Succeeded)
            {
                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(TMSJwtTokens.Key));
                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                var claims = new[]
                {
                    new Claim(JwtRegisteredClaimNames.Sub, username),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim(JwtRegisteredClaimNames.UniqueName, username)
                };
                var token = new JwtSecurityToken(
                        TMSJwtTokens.Issuer,
                        TMSJwtTokens.Audience,
                        claims,
                        expires: DateTime.UtcNow.AddMinutes(30),
                        signingCredentials: creds
                    );

                var results = new
                {
                    token = new JwtSecurityTokenHandler().WriteToken(token),
                    expritaion = token.ValidTo
                };

                return Created("", results);
            }

            return Ok();
        }

        [HttpPost]
        [Route("[action]")]
        public async Task<IActionResult> Register()
        {
            var msg = "User already registered";
            try
            {
                User user = await UserManager.FindByNameAsync("TestUser");
                if (user == null)
                {
                    user = new User()
                    {
                        UserName = "TestUser",
                        Email = "testUser@test.com",
                        FirstName = "John",
                        LastName = "Doe",
                        UserRoleID = Guid.Parse("56860de3-f338-449c-be26-c946d4cb73b0") // NormalUser
                    };

                    IdentityResult result = await UserManager.CreateAsync(user, "Test123!");
                    msg = "User was created";
                }
            }
            catch (Exception ex)
            {
                msg = ex.Message;
            }
            return Ok(msg);
        }

        [HttpPost]
        [Route("[action]")]
        public async Task<IActionResult> Login([FromQuery] string userName, [FromQuery] string password)
        {
            var result = await SignInManager.PasswordSignInAsync(userName, password, false, false);
            if (result.Succeeded)
            {
                return Ok("Login successful");
            }
            else
            {
                return NotFound("User not found.");
            }
        }

        [HttpPost]
        [Route("[action]")]
        public async Task<IActionResult> Logout()
        {
            await SignInManager.SignOutAsync();
            return Ok("Logout successful");
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserResponseDto>>> GetUsers([FromQuery] PaginationFilter paginationFilter)
        {
            var users = await userService.GetAllAsync(paginationFilter);

            return Ok(mapper.Map<List<UserResponseDto>>(users));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetUserById(Guid id)
        {
            var User = await userService.GetByIdAsync(id);

            if (User == null)
            {
                return NotFound();
            }

            return Ok(mapper.Map<UserResponseDto>(User));
        }

        [HttpPost]
        public async Task<IActionResult> AddNewUser([FromBody] UserPostDto userPostDto)
        {
            var userResp = await userService.AddAsync(userPostDto);

            return CreatedAtAction("GetClient", new { id = userResp.Id }, mapper.Map<UserResponseDto>(userResp));
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Edit([FromQuery] Guid id, [FromBody] UserPutDto userPutDto)
        {
            if (id != userPutDto.Id)
            {
                return BadRequest();
            }

            await userService.UpdateAsync(userPutDto);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(Guid id)
        {
            var success = await userService.RemoveByIdAsync(id);

            if (!success)
            {
                return NotFound();
            }

            return NoContent();
        }
    }
}
