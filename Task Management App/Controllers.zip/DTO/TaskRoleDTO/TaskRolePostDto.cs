﻿namespace Task_Management_System.Models.Dtos
{
    public class TaskRolePostDto
    {
        public string Name { get; set; }
    }
}
