﻿using System;

namespace Task_Management_System.Models.Dtos
{
    public class TaskRoleResponseDto
    {
        public Guid ID { get; set; }
        public string Name { get; set; }
    }
}
