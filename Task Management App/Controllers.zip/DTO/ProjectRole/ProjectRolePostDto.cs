﻿using System;

namespace Task_Management_System.Models.DTO.ProjectRole
{
    public class ProjectRolePostDto
    {
        public string Name { get; set; }
    }
}
