﻿using System;

namespace Task_Management_System.Models.DTO.ProjectRole
{
    public class ProjectRoleResponseDto
    {
        public Guid ID { get; set; }
        public string Name { get; set; }
    }
}
