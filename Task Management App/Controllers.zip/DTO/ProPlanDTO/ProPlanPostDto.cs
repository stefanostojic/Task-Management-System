﻿namespace Task_Management_System.Models.Dtos
{
    public class ProPlanPostDto
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public bool Active { get; set; }
    }
}
