﻿using System;

namespace Task_Management_System.Models.DTO.Label
{
    public class LabelResponseDto
    {
        public Guid ID { get; set; }
        public string Name { get; set; }
    }
}
