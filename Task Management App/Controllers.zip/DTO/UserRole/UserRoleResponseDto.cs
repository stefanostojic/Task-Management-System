﻿using System;

namespace Task_Management_System.Models.DTO.UserRole
{
    public class UserRoleResponseDto
    {
        public Guid ID { get; set; }
        public string Name { get; set; }
    }
}
