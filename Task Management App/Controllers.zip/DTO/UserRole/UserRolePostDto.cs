﻿namespace Task_Management_System.Models.DTO.UserRole
{
    public class UserRolePostDto
    {
        public string Name { get; set; }
    }
}
