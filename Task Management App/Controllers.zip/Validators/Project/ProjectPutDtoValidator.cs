﻿using FluentValidation;
using Task_Management_System.Models.Dtos;

namespace Task_Management_System.Validators
{
    public class ProjectPutDtoValidator : AbstractValidator<ProjectPutDto>
    {
        public ProjectPutDtoValidator()
        {
            RuleFor(ur => ur.ID)
                .NotNull();
            RuleFor(Project => Project.Name)
                .MinimumLength(1)
                .MaximumLength(15);
        }
    }
}
